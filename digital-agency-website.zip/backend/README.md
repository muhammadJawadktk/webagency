// Placeholder: backend/README.md
