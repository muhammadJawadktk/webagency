// Placeholder: backend/scripts/seed.js
