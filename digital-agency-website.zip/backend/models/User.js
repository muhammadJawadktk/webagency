// Placeholder: backend/models/User.js
