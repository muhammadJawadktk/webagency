// Placeholder: backend/models/Subscriber.js
