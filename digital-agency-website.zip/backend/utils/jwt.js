// Placeholder: backend/utils/jwt.js
