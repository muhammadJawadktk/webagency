// Placeholder: frontend/src/components/ChatBot.jsx
