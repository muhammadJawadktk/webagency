// Placeholder: frontend/src/pages/About.jsx
