// Placeholder: frontend/src/services/api.js
