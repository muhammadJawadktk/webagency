// Placeholder: frontend/src/services/auth.js
