// Placeholder: frontend/README.md
