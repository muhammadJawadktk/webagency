// Placeholder: docs/SETUP_GUIDE.md
