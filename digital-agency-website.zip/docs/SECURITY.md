// Placeholder: docs/SECURITY.md
